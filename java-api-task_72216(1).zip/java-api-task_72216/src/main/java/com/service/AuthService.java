package com.service;

import com.Entity.RequestBodyUser;
import com.Entity.User;
import com.config.CommonResource;
import com.dto.MetaDTO;
import com.dto.ResponseMetaData;
import com.jwt.JwtUtils;
import com.repository.UserRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Service
public class AuthService {
    @Autowired
    UserRepository repository;

    @Autowired
    private JwtUtils jwtUtils;

    public ResponseMetaData registerUser(RequestBodyUser requestBodyUser) {
        String hash = DigestUtils.md5Hex(requestBodyUser.getPassword()).toUpperCase();
        User user = new User(requestBodyUser.getUserName(), hash);
        repository.save(user);
        return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.SUCCESS), user.toString());
    }

    public ResponseMetaData loginUser(RequestBodyUser requestBodyUser) {
        User user = repository.findByUserName(requestBodyUser.getUserName());
        if (user == null) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.NOT_FOUND), null);
        }
        String hash = DigestUtils.md5Hex(requestBodyUser.getPassword()).toUpperCase();
        if (!user.getPassword().equals(hash)) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.BAD_REQUEST), null);
        }
        String token = jwtUtils.generateToken(requestBodyUser.getUserName());
        user.setToken(token);
        user.setExpiredTime(jwtUtils.getExpirationFromToken(token));
        repository.save(user);
        return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.SUCCESS), "Token: " + token);
    }

    public ResponseMetaData JwtAuthUser(HttpServletRequest request) {
        Date now = new Date();
        String token = getTokenFromRequest(request);

        if (token == null) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.INVALID_TOKEN), null);
        }
        User user = repository.findByToken(token);
        if (user == null) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.INVALID_TOKEN), null);
        }

        if (now.getTime() > user.getExpiredTime().getTime()) {
            user.setExpiredTime(null);
            user.setToken(null);
            repository.save(user);
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.BAD_REQUEST), "Token Expired");
        }
        return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.SUCCESS), "Token: " + token);

    }

    private String getTokenFromRequest(HttpServletRequest request) {
        String header = request.getHeader("Authorization");

        if (StringUtils.hasText(header) && header.startsWith("Bearer ")) {
            return header.substring(7, header.length());
        }

        return null;
    }

}

package com.service;

import com.Entity.RequestBodyUser;
import com.Entity.User;
import com.config.CommonResource;
import com.dto.MetaDTO;
import com.dto.ResponseMetaData;
import com.jwt.JwtUtils;
import com.repository.UserRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;

@Service
public class AuthService {
    @Autowired
    UserRepository repository;

    @Autowired
    private JwtUtils jwtUtils;

    @Value("${app.jwtExpirationMs}")
    private int JWT_EXPIRATION_MS;

    public ResponseMetaData registerUser(RequestBodyUser requestBodyUser) {
        String hash = DigestUtils.md5Hex(requestBodyUser.getPassword()).toUpperCase();
        User user = new User(requestBodyUser.getUserName(), hash);
        repository.save(user);
        return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.PENDING_ACCOUNT), user.toString());
    }

    public ResponseMetaData loginUser(RequestBodyUser requestBodyUser) {
        User user = repository.findByUserName(requestBodyUser.getUserName());
        if (user == null) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.NOT_FOUND), null);
        }
        String hash = DigestUtils.md5Hex(requestBodyUser.getPassword()).toUpperCase();
        if (!user.getPassword().equals(hash)) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.BAD_REQUEST), null);
        }
        String token = jwtUtils.generateToken(requestBodyUser.getUserName());
        user.setToken(token);
        user.setExpiredTime(new Timestamp((Instant.now().toEpochMilli() + JWT_EXPIRATION_MS)));
        repository.save(user);
        return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.SUCCESS), "Token: " + token);
    }

    public ResponseMetaData validateToken(String token) {
        Instant now = Instant.now();
        if (token == null) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.INVALID_TOKEN), null);
        }
        User user = repository.findByToken(token);
        if (user == null) {
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.INVALID_TOKEN), null);
        }

        if (now.toEpochMilli()> user.getExpiredTime().toInstant().toEpochMilli()) {
            user.setExpiredTime(null);
            user.setToken(null);
            repository.save(user);
            return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.BAD_REQUEST), "Token Expired");
        }
        return new ResponseMetaData(new MetaDTO(CommonResource.MetaData.SUCCESS), "Token: " + token);

    }

}

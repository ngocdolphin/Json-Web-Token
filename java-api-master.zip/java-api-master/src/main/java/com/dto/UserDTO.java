package com.dto;


import com.Entity.User;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
public class UserDTO {
    private Long id;
    private String userName;
    private String password;
    private String email;
    private String token;
    private Timestamp expiredTime;

    public UserDTO(User user) {
        this.token = user.getToken();
        this.expiredTime = user.getExpiredTime();
    }

    public UserDTO(String token, Timestamp expiredTime) {
        this.token = token;
        this.expiredTime = expiredTime;
    }
}

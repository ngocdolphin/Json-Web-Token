package com.controller;

import com.Entity.RequestBodyUser;
import com.config.CommonResource;
import com.dto.MetaDTO;
import com.dto.ResponseMetaData;
import com.jwt.JwtUtils;
import com.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
@Slf4j
@RequestMapping("${app.auth-url}")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/sign-up")
    public ResponseEntity<ResponseMetaData> signup(HttpServletRequest request, @RequestBody RequestBodyUser requestBodyUser) {
        log.info("Signing up with user: {}", requestBodyUser.getUserName());
        ResponseMetaData loginResponseDTO = authService.registerUser(requestBodyUser);
        return ResponseEntity.status(CommonResource.MetaData.PENDING_ACCOUNT.getMetaCode())
                .body(loginResponseDTO);
    }

    @PostMapping("/sign-in")
    public ResponseEntity<ResponseMetaData> signin(HttpServletRequest request, @RequestBody RequestBodyUser requestBodyUser) {
        log.info("Signing in with user: {}", requestBodyUser.getUserName());
        ResponseMetaData loginResponseDTO = authService.loginUser(requestBodyUser);
        if (!CommonResource.MetaData.SUCCESS.getMetaCode().equals(((MetaDTO) loginResponseDTO.getMeta()).getCode())) {
            return ResponseEntity.status(CommonResource.MetaData.BAD_REQUEST.getMetaCode()).body(loginResponseDTO);
        }
        return ResponseEntity.status(CommonResource.MetaData.SUCCESS.getMetaCode()).body(loginResponseDTO);
    }

    @PostMapping("/validate")
    public ResponseEntity<ResponseMetaData> validateJwt(HttpServletRequest request) {
        String token = jwtUtils.getTokenFromRequest(request);
        ResponseMetaData loginResponseDTO = authService.validateToken(token);
        return ResponseEntity.status(CommonResource.MetaData.SUCCESS.getMetaCode())
                .body(loginResponseDTO);
    }
}
